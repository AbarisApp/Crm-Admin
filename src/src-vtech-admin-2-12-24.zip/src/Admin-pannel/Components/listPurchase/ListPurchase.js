import { Link } from "react-router-dom";
import Multiselect from 'multiselect-react-dropdown';
import { useDeleteOrderMutation, useDeleteRowPurchaseMutation, useGetListPurchaseQuery } from "../all-products/allproductsApi/allProductsApi";
import { useEffect, useState } from "react";
import { Pagination } from "antd";
import axios from "axios";

function ListPurchase() {
    const [filterInpVal, setFilterInpVal] = useState({
        reference_id: '',
        start_date: '',
        end_date: '',
        product_name: '',
    });
    const handleFilterChange = (e) => {
        const inpName = e.target.name;
        const inpVal = e.target.value;
        const cloned = { ...filterInpVal };
        cloned[inpName] = inpVal;
        setFilterInpVal(cloned);
    };

    const [allSellerList, setAllSellerList] = useState([]);
    const [finalSellerD, setFinalSellerD] = useState();
    const [pickupPointsD, setPickupPointsD] = useState([]);
    const [finalpickupPointsD, setFinalpickupPointsD] = useState();
    const [collection, setCollection] = useState([]);
    const [finalCollectionD, setFinalCollectionD] = useState();
    const [brands, setBrands] = useState([]);
    const [finalBrandsD, setFinalBrandsD] = useState();
    const [industys, setIndustrys] = useState([]);
    const [finalIndustryD, setFinalIndustryD] = useState();

    const [isLoadingg, setIsLoadingg] = useState();
    const [hitFilterApi, setHitFilterApi] = useState(false);
    const [bArr, setBArr] = useState([]);
    const [totalCount, setTotalCount] = useState();
    const [pageIndex, setPageIndex] = useState(0)
    const [countToShowInTable, setCountToShowInTable] = useState(10)

    const token = window.localStorage.getItem('adminToken')


    // const { isLoading, data } = useGetListPurchaseQuery(window.localStorage.getItem('token'));
    const [deleteListPurchase, response] = useDeleteRowPurchaseMutation();
    const deleteOrderData = (id) => {
        deleteListPurchase({ id: id, token: window.localStorage.getItem('token') })
    };
    useEffect(() => {
        if (response.isSuccess === true) {
            alert('ListPurchase deleted Successfully')
        }
    }, [response]);



    const getAllProductsList = async (pageNo) => {
        const obj = { pickupPoints: [], sellers: [], category: [], brands: [], industry: [], page: pageNo, count: 10 };
        if (hitFilterApi) {
            handleSubmitFilter(pageNo)
        } else {
            try {
                setIsLoadingg(true)
                const res = await axios.post('https://onlineparttimejobs.in/api/purchase', obj, {
                    headers: {
                        "Content-type": "application/json; charset=UTF-8",
                        Authorization: `Bearer ${token}`,
                    },
                });
                console.log('paginationBARR--', res?.data)
                setBArr(res?.data?.getPurchases);
                setTotalCount(res?.data?.totalCount);
                setIsLoadingg(false);
            } catch (error) {
                setIsLoadingg(false);
            }
        }

    };
    useEffect(() => {
        getAllProductsList(0);
    }, []);
    const onChangeVal = (e) => {
        getAllProductsList(e - 1)
        setPageIndex(e - 1)
    };

    const getAllSellersD = async () => {
        const getCategoryName = []
        const reqData = await axios.get(`https://onlineparttimejobs.in/api/sellerList`, {
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        });

        for (let i = 0; i < reqData?.data.length; i++) {
            getCategoryName.push({ name: reqData?.data[i]?.firstname + " " + reqData?.data[i]?.lastname, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
        };
        if (getCategoryName.length) {
            setAllSellerList(getCategoryName);
        }
    };

    const getCollectionData = async () => {
        const getCategoryName = []
        const reqData = await axios.get(`https://onlineparttimejobs.in/api/category/admin`, {
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        });

        for (let i = 0; i < reqData?.data.length; i++) {
            getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
        };
        if (getCategoryName.length) {
            setCollection(getCategoryName);
        }
    };
    const getBrandsData = async () => {
        const getCategoryName = []
        const reqData = await axios.get(`https://onlineparttimejobs.in/api/brand/admin`, {
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        });

        for (let i = 0; i < reqData?.data.length; i++) {
            getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
        };
        if (getCategoryName.length) {
            setBrands(getCategoryName);
        }
    };
    const getIndustryData = async () => {
        const getCategoryName = []
        const reqData = await axios.get(`https://onlineparttimejobs.in/api/industry/admin`, {
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        });

        for (let i = 0; i < reqData?.data.length; i++) {
            getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
        };
        if (getCategoryName.length) {
            setIndustrys(getCategoryName);
        }
    };
    const getPickupPointsData = async () => {
        const getCategoryName = []
        const reqData = await axios.get(`https://onlineparttimejobs.in/api/pickupPoints/admin`, {
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        });

        for (let i = 0; i < reqData?.data.length; i++) {
            getCategoryName.push({ name: reqData?.data[i]?.pickupPoint_name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
        };
        if (getCategoryName.length) {
            setPickupPointsD(getCategoryName);
        }
    };

    useEffect(() => {
        getAllSellersD()
        getBrandsData()
        getIndustryData()
        getCollectionData()
        getPickupPointsData()
    }, []);


    const handleSubmitFilter = async (pageN) => {
        const obj = { ...filterInpVal, pickupPoints: finalpickupPointsD, sellers: finalSellerD, category: finalCollectionD, brands: finalBrandsD, industry: finalIndustryD, page: pageN, count: 10 }
        try {
            setIsLoadingg(true)
            const res = await axios.post('https://onlineparttimejobs.in/api/purchase', obj, {
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: `Bearer ${token}`,
                },
            });
            setBArr(res?.data?.getPurchases);
            setTotalCount(res?.data?.totalCount);
            setHitFilterApi(true);
            setIsLoadingg(false);
        } catch (error) {
            setIsLoadingg(false);
        }
    };


    return (
        <>
            <div className="aiz-main-content">
                {isLoadingg && <div className="preloaderCount">
                    <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                </div>}
                <div className="px-15px px-lg-25px">
                    <div className="card">
                        <div className="row p-3">
                            <div className="col-lg-12 text-left">
                                <h4 className="mb-md-0 h6">List Purchases</h4>
                            </div>
                        </div>

                        <form id="sort_orders">
                            <div className="card-header row gutters-5">

                                <div className="col-lg-4">
                                    <label>Start Date</label>
                                    <div className="form-group mb-0">
                                        <input type="date" className="aiz-date-range form-control" value={filterInpVal?.start_date} onChange={handleFilterChange} name="start_date" placeholder="" data-format="DD-MM-Y" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <label>End Date</label>
                                    <div className="form-group mb-0">
                                        <input
                                            type="date"
                                            className="form-control"
                                            id="search"
                                            value={filterInpVal?.end_date} onChange={handleFilterChange}
                                            name="end_date"
                                            placeholder=""
                                            fdprocessedid="wffmea"
                                        />
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <label>Reference ID</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" value={filterInpVal?.reference_id} onChange={handleFilterChange} name="reference_id" placeholder="Reference ID" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-4 mt-2">
                                    <label>Product Name</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Product Name" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-4 mt-2">
                                    <label>Seller</label>
                                    <Multiselect
                                        isObject={true}
                                        displayValue="name"
                                        options={allSellerList}
                                        showCheckbox
                                        selectedValues={[]}
                                        onRemove={(selectedCat) => {
                                            const selectedIds = selectedCat.map((cat) => {
                                                return cat._id
                                            })
                                            setFinalSellerD(selectedIds)
                                        }}
                                        onSelect={(selectedCat) => {
                                            const selectedIds = selectedCat.map((cat) => {
                                                return cat._id
                                            })
                                            setFinalSellerD(selectedIds)
                                        }}
                                    />
                                </div>

                                <div className="col-lg-4 mt-2">
                                    <label>Pickup Point</label>
                                    <Multiselect
                                        isObject={true}
                                        displayValue="name"
                                        options={pickupPointsD}
                                        showCheckbox
                                        selectedValues={[]}
                                        onRemove={(selectedCat) => {
                                            const selectedIds = selectedCat.map((cat) => {
                                                return cat._id
                                            })
                                            setFinalpickupPointsD(selectedIds)
                                        }}
                                        onSelect={(selectedCat) => {
                                            const selectedIds = selectedCat.map((cat) => {
                                                return cat._id
                                            })
                                            setFinalpickupPointsD(selectedIds)
                                        }}
                                    />
                                </div>

                                <div className="col-lg-4 mt-2">
                                    <label className="col-md-12 col-from-label">Category</label>
                                    <div id="category">
                                        <Multiselect
                                            isObject={true}
                                            displayValue="name"
                                            options={collection}
                                            showCheckbox
                                            // selectedValues={item?.Collection}
                                            onRemove={(selectedCat) => {
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalCollectionD(selectedIds)
                                            }}
                                            onSelect={(selectedCat) => {
                                                // setFinalCatD(event)
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalCollectionD(selectedIds)
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="col-lg-4 mt-2">
                                    <label className="col-md-12 col-from-label">Brand</label>
                                    <div id="category">
                                        <Multiselect
                                            isObject={true}
                                            displayValue="name"
                                            options={brands}
                                            showCheckbox
                                            // selectedValues={item?.Collection}
                                            onRemove={(selectedCat) => {
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalBrandsD(selectedIds)
                                            }}
                                            onSelect={(selectedCat) => {
                                                // setFinalCatD(event)
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalBrandsD(selectedIds)
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="col-lg-4 mt-2">
                                    <label className="col-md-12 col-from-label">Industry</label>
                                    <div id="category">
                                        <Multiselect
                                            isObject={true}
                                            displayValue="name"
                                            options={industys}
                                            showCheckbox
                                            // selectedValues={item?.Collection}
                                            onRemove={(selectedCat) => {
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalIndustryD(selectedIds)
                                            }}
                                            onSelect={(selectedCat) => {
                                                // setFinalCatD(event)
                                                const selectedIds = selectedCat.map((cat) => {
                                                    return cat._id
                                                })
                                                setFinalIndustryD(selectedIds)
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="col-lg-4 mt-3">
                                    <div className="form-group mb-0 mt-3">
                                        <button
                                            type="button"
                                            onClick={() => handleSubmitFilter(0)}
                                            className="btn btn-primary"
                                            fdprocessedid="24gy4"
                                        >
                                            Filter
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>


                        <div className="card-body">
                            <table className="table aiz-table mb-0 footable footable-1 breakpoint-xl" >
                                <thead>
                                    <tr className="footable-header">

                                        <th
                                            className="footable-first-visible"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            S.No
                                        </th>
                                        {/* <th style={{ display: "table-cell" }}>Master Order Id</th> */}
                                        {/* <th style={{ display: "table-cell" }}>Child Order Id</th> */}

                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Purchases Date
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Reference No
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Supplier Name
                                        </th>
                                        {/* <th
                                                data-breakpoints="md"
                                                style={{ display: "table-cell" ,textAlign:'center'}}
                                            >
                                                Order Net Amount
                                            </th> */}
                                        {/* <th
                                                data-breakpoints="md"
                                                style={{ display: "table-cell" ,textAlign:'center'}}
                                            >
                                                Payment Mode
                                            </th> */}

                                        {/* <th
                                                data-breakpoints="md"
                                                style={{ display: "table-cell" ,textAlign:'center'}}
                                            >
                                                Order Delivery Status
                                            </th> */}
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Pickup Point
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Total Qty
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Grand Amount
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Tax Amount
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Net Amount
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Payment Status
                                        </th>
                                        <th
                                            data-breakpoints="md"
                                            style={{ display: "table-cell", textAlign: 'center' }}
                                        >
                                            Delivery Status
                                        </th>

                                        <th
                                            className="footable-last-visible"
                                            style={{}}
                                        >
                                            Options
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {bArr && bArr?.map((item, i) => {
                                        return <tr key={i}>
                                            <td
                                                className="footable-first-visible"
                                                style={{ display: "table-cell", textAlign: 'center' }}
                                            >
                                                {(pageIndex * countToShowInTable) + i + 1}
                                            </td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}>{item?.createdAt}</td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}>{item?.referenceNo}</td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}>
                                                {/* {item?.supplier?.length ? item?.supplier[0]?.firstname + " " + item?.supplier[0]?.lastname : 'ETG'} */}
                                                {item?.supplier_first + " " + item?.supplier_last}
                                            </td>

                                            <td style={{ display: "table-cell", textAlign: 'center' }}>
                                                {item?.pickupPoints?.map((item, i) => {
                                                    return <>
                                                        <span key={i}>{item}</span><br></br>
                                                    </>
                                                })}
                                            </td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}></td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}></td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}></td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}></td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}></td>
                                            <td style={{ display: "table-cell", textAlign: 'center' }}>
                                                {item?.status === "Pending" ?  <span style={{ padding: '5px 10px', borderRadius: '5px', backgroundColor: 'yellow' }}> {item?.status}</span>:<span style={{ padding: '5px 10px', borderRadius: '5px', backgroundColor: 'green' }}> {item?.status}</span> }
                                              
                                            </td>
                                            <td
                                                className="text-right footable-last-visible"
                                                style={{ display: "inline-flex" }}
                                            >
                                                <Link
                                                    className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                                    // to={`/admin/all_orders/order-Details/${item?._id}`}
                                                    to={'#'}
                                                    title="View"
                                                >
                                                    <i className="las la-edit" />
                                                </Link>
                                                <button type="button" onClick={() => deleteOrderData(item?._id)} className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                                    <i className="las la-trash" />
                                                </button>
                                            </td>

                                        </tr>
                                    })}

                                </tbody>
                            </table>


                            <div className="aiz-pagination">
                                <nav>
                                    {totalCount && <Pagination onChange={onChangeVal} total={totalCount} />}
                                </nav>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </>
    );
}
export default ListPurchase;
