import React from 'react'
import AddCategoryTypeJwellsComp from '../addCategoryTypeJwellsComp/AddCategoryTypeJwellsComp'

function EditCategoryTypeJwellsComp() {
    return (
        <>
            <AddCategoryTypeJwellsComp />
        </>
    )
}

export default EditCategoryTypeJwellsComp