import React from 'react'
import AddEditBlogCategoryPage from '../../Pages/AddEditBlogCategoryPage'

function EditBlogCategorryComp() {
    return (
        <>
            <AddEditBlogCategoryPage />
        </>
    )
}

export default EditBlogCategorryComp