import React from 'react'
import AddProductTagComp from '../addProductTagComp/AddProductTagComp'

function EditProductTagComp() {
    return (
        <>
            <AddProductTagComp />
        </>
    )
}

export default EditProductTagComp