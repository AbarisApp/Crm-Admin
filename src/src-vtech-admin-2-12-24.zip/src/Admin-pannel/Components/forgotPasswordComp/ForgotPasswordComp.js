import { useEffect, useState } from "react"
// import login from "../assets/img/login.png";
import login from "../../../../src/assets/img/login.png";
import { Link, useNavigate } from "react-router-dom";
import { AiOutlineGoogle } from "react-icons/ai";
import { BsTwitter } from "react-icons/bs";
import { FaFacebookF } from "react-icons/fa";
// import { useLoginStaffsMutation, useSellerLoginMutation } from "../Admin-pannel/Components/all-products/allproductsApi/allProductsApi";
import { Spinner } from "react-bootstrap";
// import img2 from "../assets/img/login.png"
import axios from "axios";

function ForgotPasswordComp() {
    return (
        <div className="registrationDetail"
            // style={{ backgroundColor: getDat?.backgroundColor ? getDat?.backgroundColor : '#9013FE' }}
            style={{ backgroundColor: '#9013FE' }}
        >
            <div className="container">
                <div className="registrationInfo">

                    <div className="registerForm">
                        <h4 className="mb-4">Forgot Password</h4>
                        <form className="registerFormField">
                            <div className="mb-3">
                                <label>Enter Your Email</label>
                                <input
                                    type="email"
                                    placeholder="email"
                                    className="form-control"
                                    autoComplete="off"
                                    name="email"
                                    onChange={'handleChangeLogin'}
                                />
                            </div>
                            <div className="mb-3">
                                <label>Enter Password</label>
                                <input
                                    type="password"
                                    placeholder="Password"
                                    className="form-control"
                                    autoComplete="off"
                                    name="password"
                                    onChange={'handleChangeLogin'}
                                />
                            </div>
                            {/* <div className="form-check mb-3 forgotInfo">
                                <div className="rememberText">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        defaultValue
                                        id="flexCheckDefault"
                                    />
                                    <label
                                        className="form-check-label agreeCheck"
                                        htmlFor="flexCheckDefault"
                                    >
                                        Remember Me
                                    </label>
                                </div>
                                <div className="forgotText">
                                    <Link to="#">Forgot password?</Link>
                                </div>
                            </div> */}
                            {/* {isError && <h4 style={{ color: "red" }}>login Fail ! </h4>}
                            {isSuccess && <h4>login Successfully !</h4>}
                            {isSellerErr && <h4 style={{ color: "red" }}>login Fail ! </h4>}
                            {isSellerSucc && <h4>login Successfully !</h4>}
                            {!delevery ? <button className="btn btn-primary createAccount" type="button" onClick={sendDelevery} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                                login Delivery Boy
                            </button> : showSeller ? <button className="btn btn-primary createAccount" type="button" onClick={SendSellerInfo} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                                login Seller
                                {sellerLoading && <Spinner style={{ marginLeft: "7px" }} animation="border" />}
                            </button> : <button className="btn btn-primary createAccount" type="button" onClick={handleLoginSubmit} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                                login
                                {isLoading && <Spinner style={{ marginLeft: "7px" }} animation="border" />}
                            </button>} */}

                            <button className="btn btn-primary createAccount" type="button" onClick={'handleLoginSubmit'} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                                Submit
                                {/* {isLoading && <Spinner style={{ marginLeft: "7px" }} animation="border" />} */}
                            </button>
                        </form>
                        {/* {!showSeller ? <div className="forgotText" style={{ marginTop: "10px", display: "flex", justifyContent: "center" }}>
                            <Link to="#" onClick={ShowSellerLogin}>Login Seller</Link>

                        </div> : <div className="forgotText" style={{ marginTop: "10px", display: "flex", justifyContent: "center" }}>
                            <Link to="#" onClick={ShowSellerLogin}>Login Admin</Link>
                        </div>}

                        {!delevery ? <Link to="#" onClick={showDelvery}>Login Admin</Link> : <Link to="#" onClick={showDelvery}>Login As Delevery Boy</Link>} */}
                        {/* <div className="joinWith">
                            <span>or login with</span>
                        </div>
                        <div className="connectWith">
                            <ul>
                                <li>
                                    <a href="https://mmslfashions.in/" className="facebook">
                                        <FaFacebookF />
                                    </a>
                                </li>

                                <li>
                                    <a href="https://mmslfashions.in/" className="twitter">
                                        <BsTwitter />
                                    </a>
                                </li>

                                <li>
                                    <a href="https://mmslfashions.in/" className="google">
                                        <AiOutlineGoogle />
                                    </a>
                                </li>
                            </ul>
                        </div> */}

                    </div>
                </div>





            </div>
        </div >
    )
}

export default ForgotPasswordComp