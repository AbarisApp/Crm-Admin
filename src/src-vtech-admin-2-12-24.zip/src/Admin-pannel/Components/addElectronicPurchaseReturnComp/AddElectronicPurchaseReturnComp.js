import React from 'react'

function AddElectronicPurchaseReturnComp() {
    const handelChange = (e) => {
        if (e.key === 'Enter') {
            const clone = e.target.value
            // setSearch(clone);
            // setShow(true)
        }
    }
    
  return (
    <>
            <div className="aiz-main-content">
                <div className="px-15px px-lg-25px">
                    <div className="card" style={{ padding: "10px" }}>

                        <div className="container">
                            <div className="row devTols" >
                                <div className="col-lg-3">
                                    <label>Purchase Return No</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="Purchase Return No" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3">
                                    <label>Entry Date</label>
                                    <div className="form-group mb-0">
                                        <input type="date" className="aiz-date-range form-control" name="start_date" placeholder="" data-format="DD-MM-Y" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>
                                <div className="col-lg-3 mt-2">
                                    <label>Purchase Return Account</label>
                                    <select class="form-select form-control" aria-label="Default select example">
                                        <option selected>Select Account</option>
                                        <option value="12">One</option>
                                        <option value="22">Two</option>
                                        <option value="32">Three</option>
                                    </select>
                                </div>



                                <div className="col-lg-3 mt-2">
                                    <label>Supplier Name</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="product_name" placeholder="Supplier Name" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>DC Entry No</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="product_name" placeholder="DC Entry No" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>Supplier CN No</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="product_name" placeholder="Supplier CN No" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>Supplier CN Date</label>
                                    <div className="form-group mb-0">
                                        <input type="date" className="aiz-date-range form-control" name="product_name" placeholder="Suppliers Inv. No." autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>Purchase Invoice No</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="product_name" placeholder="Purchase Invoice No" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>Purchase Invoice Date</label>
                                    <div className="form-group mb-0">
                                        <input type="date" className="aiz-date-range form-control" name="product_name" placeholder="" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                            </div>
                        </div>



                        {/* <div className="container">
                            <div className="row">
                                <div className="col">
                                    <div>
                                        <label>Products</label>
                                        <input className="form-control" onKeyDown={handelChange} placeholder="Please add products to order list" />
                                        {show && searchPro?.getSearchedProduct?.length > 0 && <div className="showList">
                                    <div style={{ fontSize: "19px" }} onClick={() => { setShow(false) }}><RxCross1 /></div>
                                    {searchPro?.getSearchedProduct.map((item) => {
                                        return <h6 key={item._id} style={{ cursor: "pointer" }} onClick={() => setTableItem(item)}>{item.name}</h6>
                                    })}
                                </div>}
                                    </div>
                                </div>
                            </div>
                        </div> */}


                        <div className="container">
                            <h4 className='mt-4'>Product Detail</h4>
                            <div className="card mt-3 rest-part col-lg-12 mb-0">
                                <div className="row p-0">
                                    <div className="col-12 sku_combination table-responsive form-group p-0 m-0" id="sku_combination">
                                        <table className="table table-bordered physical_product_show">
                                            <thead>
                                                <tr>
                                                    <td><label className="control-label">Sr.No.</label></td>
                                                    <td><label className="control-label" style={{ width: "200px", }}>Product Name</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Quantity</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Basic Rate</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Basic Amount</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>CGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>SGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>IGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Amount</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}></label></td>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <label name="varient" className="control-label">1</label>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <button className='btn btn-primary' type='button'>
                                                            Add
                                                        </button>
                                                    </td>
                                                </tr>
                                                {/* 
                                            {showData && showData.map((item, i) => {
                                                return <GenerateTr changeSkuvalue={changeSkuvalue} showData={showData} setShowData={setShowData} DeleteRow={DeleteRow} key={i} item={item} index={i} pickUp={pickUp} />
                                            })} */}
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="container">
                            <h4 className='mt-4'>Other Charges</h4>
                            <div className="card mt-3 rest-part col-lg-12 mb-0">
                                <div className="row p-0">
                                    <div className="col-12 sku_combination table-responsive form-group p-0 m-0" id="sku_combination">
                                        <table className="table table-bordered physical_product_show">
                                            <thead>
                                                <tr>
                                                    <td><label className="control-label">Sr.No.</label></td>
                                                    <td><label className="control-label" style={{ width: "200px", }}>Expenses Head</label></td>
                                                    <td><label className="control-label" style={{ width: "200px", }}>Desc</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Amount</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Basic Amount</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>CGST %</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>CGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>SGST %</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>SGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>IGST %</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>IGST Amt</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}>Amt With Tax</label></td>
                                                    <td><label className="control-label" style={{ width: "100px", }}></label></td>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <label name="varient" className="control-label">1</label>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <button className='btn btn-primary' type='button'>
                                                            Add
                                                        </button>
                                                    </td>
                                                </tr>
                                                {/* 
                                            {showData && showData.map((item, i) => {
                                                return <GenerateTr changeSkuvalue={changeSkuvalue} showData={showData} setShowData={setShowData} DeleteRow={DeleteRow} key={i} item={item} index={i} pickUp={pickUp} />
                                            })} */}
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="container">
                        <h4 className='mt-4'>Final Detail</h4>
                            <div className="row devTols" >

                                <div className="col-lg-2">
                                    <label>Basic Total</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="Basic Total" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-2">
                                    <label>CGST Total</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="CGST Total" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>
                                <div className="col-lg-2">
                                    <label>SGST Total</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="SGST Total" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>
                                <div className="col-lg-2">
                                    <label>IGST Total</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="IGST Total" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>
                                <div className="col-lg-2">
                                    <label>Round off</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="Round off" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>
                                <div className="col-lg-2">
                                    <label>Final Total</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="Final Total" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                            </div>
                        </div>


                        <div className="container">
                            <div className="row mt-2 mb-3">
                                <div className="col-12">
                                    <label>Remark / Narration</label>
                                    <textarea className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <div style={{ marginLeft: "60px", display: "flex" }}>
                            <button type="button" style={{ display: "flex", alignContent: "center" }} className="btn btn-primary">Save </button>
                            <button type="button" className="btn btn-danger" style={{ marginLeft: "10px" }}>Reset</button>
                            <button type="button" className="btn btn-secondary" style={{ marginLeft: "10px" }}>Close</button>
                        </div>
                    </div>

                </div>
                <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto"></div>
            </div>
        </>
  )
}

export default AddElectronicPurchaseReturnComp