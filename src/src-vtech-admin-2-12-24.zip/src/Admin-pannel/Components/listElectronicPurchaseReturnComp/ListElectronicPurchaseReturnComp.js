import { Link } from "react-router-dom";
import { useState } from "react";

function ListElectronicPurchaseReturnComp() {
    const [filterInpVal, setFilterInpVal] = useState({
        reference_id: '',
        start_date: '',
        end_date: '',
        product_name: '',
    });
    const handleFilterChange = (e) => {
        const inpName = e.target.name;
        const inpVal = e.target.value;
        const cloned = { ...filterInpVal };
        cloned[inpName] = inpVal;
        setFilterInpVal(cloned);
    };

    const handleSubmitFilter = async () => {

    };

  return (
    <>
    <div className="aiz-main-content">
        {/* {isLoadingg && <div className="preloaderCount">
        <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
        </div>
    </div>} */}
        <div className="px-15px px-lg-25px">
            <div className="card">
                <div className="row p-3">
                    <div className="col-lg-12 text-left">
                        <h4 className="mb-md-0 h6">Purchase Return / Debit Note</h4>
                    </div>
                </div>

                <form id="sort_orders">
                    <div className="card-header row gutters-5">
                        <div className="col-lg-4">
                            <label>Purchase Return No</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.reference_id} onChange={handleFilterChange} name="reference_id" placeholder="Purchase Return No" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>

                        <div className="col-lg-4">
                            <label>Date</label>
                            <div className="form-group mb-0">
                                <input type="date" className="aiz-date-range form-control" value={filterInpVal?.start_date} onChange={handleFilterChange} name="start_date" placeholder="" data-format="DD-MM-Y" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>

                        <div className="col-lg-4 mt-2">
                            <label>Supplier Name</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Supplier Name" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>

                        <div className="col-lg-4 mt-2">
                            <label>Supplier CN No</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Supplier CN No" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <label>Supplier CN Date</label>
                            <div className="form-group mb-0">
                                <input type="date" className="aiz-date-range form-control" value={filterInpVal?.start_date} onChange={handleFilterChange} name="start_date" placeholder="" data-format="DD-MM-Y" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>
                        <div className="col-lg-4 mt-2">
                            <label>Product</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Product" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>



                        <div className="col-lg-4 mt-2">
                            <label>Qty</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Qty" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>
                       
                        <div className="col-lg-4 mt-2">
                            <label>Final Total</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Final Total" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>
                        <div className="col-lg-4 mt-2">
                            <label>Remark</label>
                            <div className="form-group mb-0">
                                <input type="text" className="aiz-date-range form-control" value={filterInpVal?.product_name} onChange={handleFilterChange} name="product_name" placeholder="Remark" autoComplete="off" fdprocessedid="sq6vu7" />
                            </div>
                        </div>


                        <div className="col-lg-4 mt-3">
                            <div className="form-group mb-0 mt-3">
                                <button
                                    type="button"
                                    onClick={() => handleSubmitFilter(0)}
                                    className="btn btn-primary"
                                    fdprocessedid="24gy4"
                                >
                                    Filter
                                </button>
                            </div>
                        </div>
                    </div>
                </form>


                <div className="card-body">
                    <table className="table aiz-table mb-0 footable footable-1 breakpoint-xl" >
                        <thead>
                            <tr className="footable-header">

                                <th
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    S.No
                                </th>

                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Purchase Return No
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                     Date
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Supplier Name
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Supplier CN No
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Supplier CN Date
                                </th>

                                
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Product
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Qty
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Final Total
                                </th>
                                <th
                                    data-breakpoints="md"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    Remark
                                </th>


                                <th
                                    className="footable-last-visible"
                                    style={{}}
                                >
                                    Options
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    1
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>HO222303PO0001</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>31-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                BOJOJ OLLYONZ GENEROL YNCURONCE CO. LTD
                                </td>

                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                133453169/4
                                </td>
                               
                                <td style={{ display: "table-cell", textAlign: 'center' }}>16-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                GENERAL ITEMS
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                0.00
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                12,168.16
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center',}}>
                                CASH DISCOUNT DEC 21	
                                </td>
                                <td
                                    className="text-right footable-last-visible"
                                    style={{ display: "inline-flex" }}
                                >
                                    <Link
                                        className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                        // to={`/admin/all_orders/order-Details/${item?._id}`}
                                        to={'#'}
                                        title="View"
                                    >
                                        <i className="las la-edit" />
                                    </Link>
                                    <button type="button" className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                        <i className="las la-trash" />
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    2
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>HO222303PO0001</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>31-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                BOJOJ OLLYONZ GENEROL YNCURONCE CO. LTD
                                </td>

                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                133453169/4
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>16-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                GENERAL ITEMS
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                0.00
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                12,168.16
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center',}}>
                                CASH DISCOUNT DEC 21	
                                </td>
                                <td
                                    className="text-right footable-last-visible"
                                    style={{ display: "inline-flex" }}
                                >
                                    <Link
                                        className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                        // to={`/admin/all_orders/order-Details/${item?._id}`}
                                        to={'#'}
                                        title="View"
                                    >
                                        <i className="las la-edit" />
                                    </Link>
                                    <button type="button" className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                        <i className="las la-trash" />
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    3
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>HO222303PO0001</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>31-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                BOJOJ OLLYONZ GENEROL YNCURONCE CO. LTD
                                </td>

                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                133453169/4
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>16-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                GENERAL ITEMS
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                0.00
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                12,168.16
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center',}}>
                                CASH DISCOUNT DEC 21	
                                </td>
                                <td
                                    className="text-right footable-last-visible"
                                    style={{ display: "inline-flex" }}
                                >
                                    <Link
                                        className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                        // to={`/admin/all_orders/order-Details/${item?._id}`}
                                        to={'#'}
                                        title="View"
                                    >
                                        <i className="las la-edit" />
                                    </Link>
                                    <button type="button" className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                        <i className="las la-trash" />
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    4
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>HO222303PO0001</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>31-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                BOJOJ OLLYONZ GENEROL YNCURONCE CO. LTD
                                </td>

                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                133453169/4
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>16-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                GENERAL ITEMS
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                0.00
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                12,168.16
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center',}}>
                                CASH DISCOUNT DEC 21	
                                </td>
                                <td
                                    className="text-right footable-last-visible"
                                    style={{ display: "inline-flex" }}
                                >
                                    <Link
                                        className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                        // to={`/admin/all_orders/order-Details/${item?._id}`}
                                        to={'#'}
                                        title="View"
                                    >
                                        <i className="las la-edit" />
                                    </Link>
                                    <button type="button" className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                        <i className="las la-trash" />
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    className="footable-first-visible"
                                    style={{ display: "table-cell", textAlign: 'center' }}
                                >
                                    5
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>HO222303PO0001</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>31-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                BOJOJ OLLYONZ GENEROL YNCURONCE CO. LTD
                                </td>

                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                133453169/4
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>16-Dec-2021</td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                GENERAL ITEMS
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                0.00
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center' }}>
                                12,168.16
                                </td>
                                <td style={{ display: "table-cell", textAlign: 'center',}}>
                                CASH DISCOUNT DEC 21	
                                </td>
                                <td
                                    className="text-right footable-last-visible"
                                    style={{ display: "inline-flex" }}
                                >
                                    <Link
                                        className="btn btn-soft-primary btn-icon btn-circle btn-sm me-2"
                                        // to={`/admin/all_orders/order-Details/${item?._id}`}
                                        to={'#'}
                                        title="View"
                                    >
                                        <i className="las la-edit" />
                                    </Link>
                                    <button type="button" className="btn btn-soft-danger btn-icon btn-circle btn-sm" title="delete">
                                        <i className="las la-trash" />
                                    </button>
                                </td>
                            </tr>
                           

                        </tbody>
                    </table>


                    <div className="aiz-pagination">

                    </div>

                </div>

            </div>
        </div>
    </div>
</>
  )
}

export default ListElectronicPurchaseReturnComp