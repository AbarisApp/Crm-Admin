import React from 'react'
import AddSizeJwellsComp from '../addSizeJwellsComp/AddSizeJwellsComp'

function EditSizeJwellsComp() {
    return (
        <>
            <AddSizeJwellsComp />
        </>
    )
}

export default EditSizeJwellsComp