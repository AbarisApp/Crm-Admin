import React from 'react'
import AddPrice from '../generalMaster/price/addPrice/AddPrice'

function EditPriceComp() {
    return (
        <>
            <AddPrice />
        </>
    )
}

export default EditPriceComp