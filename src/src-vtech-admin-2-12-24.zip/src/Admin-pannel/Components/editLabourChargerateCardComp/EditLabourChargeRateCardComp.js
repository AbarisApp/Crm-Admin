import React from 'react'
import AddLabourChargeRateCardComp from '../addLabourChargeRateCardComp/AddLabourChargeRateCardComp'

function EditLabourChargeRateCardComp() {
    return (
        <>
            <AddLabourChargeRateCardComp />
        </>
    )
}

export default EditLabourChargeRateCardComp