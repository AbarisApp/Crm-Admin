import React from 'react'
import AddStyleManagementPage from '../../Pages/addStyleManagmentPage'

function EditStyleManagementComp() {
    return (
        <>
            <AddStyleManagementPage />
        </>
    )
}

export default EditStyleManagementComp