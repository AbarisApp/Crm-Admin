import React from 'react'
import AddMetalType from '../../metalPurity/addMetalType/AddMetalType'

function EditMetalPurity() {
    return (
        <>
            <AddMetalType />
        </>
    )
}

export default EditMetalPurity