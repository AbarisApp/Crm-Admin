import React from 'react'
import AddDiamondQualityPage from '../../../../Pages/jewellery/diamond/addDiamondQuality/Index'

function EditDiamondQuality() {
    return (
        <>
            <AddDiamondQualityPage />
        </>
    )
}

export default EditDiamondQuality