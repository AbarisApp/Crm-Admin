// import { SlideshowLightbox } from "lightbox.js-react";
import { useEffect, useState } from 'react';
import Form from 'react-bootstrap/Form';
import { Link, useNavigate, useParams } from "react-router-dom";

import { useDeleteProductMutation, useGetAllProductsQuery, useGetCategoriesQuery, useProductActiveMutation } from "./allproductsApi/allProductsApi";
import { ToastContainer, toast } from "react-toastify";
import { BsFillPrinterFill } from 'react-icons/bs';
import axios from 'axios';
import ExportDataInPdf from '../../../common/exportDataInPdf/ExportDataInPdf';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import Multiselect from 'multiselect-react-dropdown';
import { Pagination } from 'antd';
// import { Pagination } from 'react-bootstrap';

function AllProducts() {
  const [isLoadingg, setIsLoadingg] = useState();
  const [hitFilterApi, setHitFilterApi] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const token = window.localStorage.getItem('adminToken')
  const { data } = useGetAllProductsQuery(token)
  const [bArr, setBArr] = useState([]);
  const [bArrr, setBArrr] = useState([]);
  const [seller, setSeller] = useState([]);
  const [sellerVal, setSellerVal] = useState([]);

  const [collection, setCollection] = useState([]);
  const [finalCollectionD, setFinalCollectionD] = useState();
  const [brands, setBrands] = useState([]);
  const [finalBrandsD, setFinalBrandsD] = useState();
  const [industys, setIndustrys] = useState([]);
  const [finalIndustryD, setFinalIndustryD] = useState();
  const [pickupPointsD, setPickupPointsD] = useState([]);
  const [finalpickupPointsD, setFinalpickupPointsD] = useState();

  const [totalCount, setTotalCount] = useState();
  const [pageIndex, setPageIndex] = useState(0)
  const [countToShowInTable, setCountToShowInTable] = useState(10)


  const params = useParams();

  const getAllProductsList = async (pageNo) => {
    const obj = { categories: [], brands: [], industries: [], page: pageNo, count: 10 };
    if (hitFilterApi) {
      filterData(pageNo)
    } else {
      try {
        setIsLoadingg(true)
        const res = await axios.post('https://onlineparttimejobs.in/api/product/filterAdmin', obj, {
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: `Bearer ${token}`,
          },
        });
        setBArr(res?.data?.getFilterProd);
        setTotalCount(res?.data?.totalCount);
        setIsLoadingg(false);
      } catch (error) {
        setIsLoadingg(false);
      }
    }

  };
  useEffect(() => {
    getAllProductsList(0);
  }, []);
  useEffect(() => {
    if (data) {
      console.log('allPData---', data)
      setBArrr(data)
    }
  }, [data]);



  const handleSellerChange = (e) => {
    setSellerVal(e.target.value)
  };
  const onChangeHandler = (e) => {
    setInputVal(e.target.value)
  };

  const [deleteData, response] = useDeleteProductMutation();

  function deleteProductData(id) {
    deleteData({ id, token })
  };

  useEffect(() => {
    if (response.isSuccess === true) {
      alert("Product deleted Successfully")
    };
  }, [response.isSuccess])


  const [updatePro, { isSuccess, isError }] = useProductActiveMutation()
  const changeStatus = (item) => {
    // const obj = { id: item._id.uid, data: { approve: !item?.product?.approve } }
    const obj = { id: item?.uid, data: { approve: !item?.approve } }
    updatePro(obj)
  }

  const toastSuccessMessage = () => {
    toast.success("Product Updated Successfully", {
      position: "top-center"
    })
  };

  const toastErrorMessage = () => {
    toast.error("Product Update Faild..", {
      position: "top-center"
    })
  };

  useEffect(() => {
    if (isSuccess === true) {
      toastSuccessMessage()
    };
  }, [isSuccess]);

  useEffect(() => {
    if (isError === true) {
      toastErrorMessage()
    };
  }, [isError])

  const navigate = useNavigate()
  const changeRouting = (id) => {
    navigate(`print_barcodes/${id}`)
  };

  const getAllSellerData = async () => {
    const reqData = await axios.get(`https://onlineparttimejobs.in/api/sellerlist/admin`, {
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: `Bearer ${token}`,
      },
    });
    setSeller(reqData?.data)
  };

  const getCollectionData = async () => {
    const getCategoryName = []
    const reqData = await axios.get(`https://onlineparttimejobs.in/api/category/admin`, {
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: `Bearer ${token}`,
      },
    });

    for (let i = 0; i < reqData?.data.length; i++) {
      getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
    };
    if (getCategoryName.length) {
      setCollection(getCategoryName);
    }
  };
  const getBrandsData = async () => {
    const getCategoryName = []
    const reqData = await axios.get(`https://onlineparttimejobs.in/api/brand/admin`, {
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: `Bearer ${token}`,
      },
    });

    for (let i = 0; i < reqData?.data.length; i++) {
      getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
    };
    if (getCategoryName.length) {
      setBrands(getCategoryName);
    }
  };
  const getIndustryData = async () => {
    const getCategoryName = []
    const reqData = await axios.get(`https://onlineparttimejobs.in/api/industry/admin`, {
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: `Bearer ${token}`,
      },
    });

    for (let i = 0; i < reqData?.data.length; i++) {
      getCategoryName.push({ name: reqData?.data[i]?.name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
    };
    if (getCategoryName.length) {
      setIndustrys(getCategoryName);
    }
  };
  const getPickupPointsData = async () => {
    const getCategoryName = []
    const reqData = await axios.get(`https://onlineparttimejobs.in/api/pickupPoints/admin`, {
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: `Bearer ${token}`,
      },
    });

    for (let i = 0; i < reqData?.data.length; i++) {
      getCategoryName.push({ name: reqData?.data[i]?.pickupPoint_name, _id: reqData?.data[i]?._id, uid: reqData?.data[i]?.uid })
    };
    if (getCategoryName.length) {
      setPickupPointsD(getCategoryName);
    }
  };

  useEffect(() => {
    getCollectionData();
    getBrandsData();
    getIndustryData();
    getAllSellerData();
    getPickupPointsData();
  }, []);

  const filterData = async (pageN) => {
    const obj = { categories: finalCollectionD, brands: finalBrandsD, industries: finalIndustryD, pickupPoints: finalpickupPointsD, seller_id: sellerVal, search: inputVal, page: pageN, count: 10 }
    try {
      setIsLoadingg(true)
      const res = await axios.post('https://onlineparttimejobs.in/api/product/filterAdmin', obj, {
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          Authorization: `Bearer ${token}`,
        },
      });
      setBArr(res?.data?.getFilterProd);
      setTotalCount(res?.data?.totalCount);
      setHitFilterApi(true);
      setIsLoadingg(false);
    } catch (error) {
      setIsLoadingg(false);
    }
  };

  const onChangeVal = (e) => {
    getAllProductsList(e - 1)
    setPageIndex(e - 1)
  };


  console.log('AllProds--', bArr)


  return (
    <>
      <div className="aiz-main-content">
        <div className="px-15px px-lg-25px">
          {isLoadingg && <div className="preloaderCount">
            <div className="spinner-border" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>}

          <div className="aiz-titlebar text-left mt-2 mb-3">
            <div className="row align-items-center">
              <div className="col-lg-6">
                <h1 className="h3">All products</h1>
              </div>
              {bArr && <div className="col-lg-2" >
                <button style={{ background: '#2e294e', padding: '0', color: 'white', borderRadius: '5px' }}>
                  <ReactHTMLTableToExcel
                    style={{ margin: '0' }}
                    id="test-table-xls-button"
                    className="download-table-xls-button cusxel"
                    table="table-to-xlsx"
                    filename="tablexls"
                    sheet="tablexls"
                    buttonText="Download Excel sheet" />
                </button>
              </div>}
              {bArr && <div className="col-lg-2 text-md-right">
                <ExportDataInPdf />
              </div>}
              <div className="col-lg-2 text-right">
                <Link to="/admin/products/all/products/create" className="btn btn-circle btn-info">
                  <span>Add New Products</span>
                </Link>
              </div>
            </div>
          </div>
          <br />

          <ToastContainer />
          <div className="card">
            <form id="sort_products">

              <div className="card-header row">
                <div className="col-md-3">
                  <h5 className="mb-md-0 h6">All Product</h5>
                </div>
              </div>

              <div className="row ps-3 pe-3 pt-3">
                <div className="form-group col-md-3">
                  <label className="col-md-12 col-from-label">Category</label>
                  <div id="category">
                    <Multiselect
                      isObject={true}
                      displayValue="name"
                      options={collection}
                      showCheckbox
                      // selectedValues={item?.Collection}
                      onRemove={(selectedCat) => {
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalCollectionD(selectedIds)
                      }}
                      onSelect={(selectedCat) => {
                        // setFinalCatD(event)
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalCollectionD(selectedIds)
                      }}
                    />
                  </div>
                </div>
                <div className="form-group col-md-3">
                  <label className="col-md-12 col-from-label">Brand</label>
                  <div id="category">
                    <Multiselect
                      isObject={true}
                      displayValue="name"
                      options={brands}
                      showCheckbox
                      // selectedValues={item?.Collection}
                      onRemove={(selectedCat) => {
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalBrandsD(selectedIds)
                      }}
                      onSelect={(selectedCat) => {
                        // setFinalCatD(event)
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalBrandsD(selectedIds)
                      }}
                    />
                  </div>
                </div>
                <div className="form-group col-md-3">
                  <label className="col-md-12 col-from-label">Industry</label>
                  <div id="category">
                    <Multiselect
                      isObject={true}
                      displayValue="name"
                      options={industys}
                      showCheckbox
                      // selectedValues={item?.Collection}
                      onRemove={(selectedCat) => {
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalIndustryD(selectedIds)
                      }}
                      onSelect={(selectedCat) => {
                        // setFinalCatD(event)
                        const selectedIds = selectedCat.map((cat) => {
                          return cat.uid
                        })
                        setFinalIndustryD(selectedIds)
                      }}
                    />
                  </div>
                </div>
                <div className="form-group col-md-3">
                  <label className="col-md-12 col-from-label">Seller</label>
                  <div>
                    <Form.Select aria-label="Default select example" onChange={handleSellerChange} className="form-control form-control-sm aiz-selectpicker mb-2 mb-md-0" >
                      <option>Select Seller</option>
                      {seller && seller?.map((item, i) => {
                        return <option value={item?._id}>{item?.firstname + " " + item?.lastname}</option>
                      })}
                    </Form.Select>
                  </div>
                </div>

                <div className="form-group col-md-3">
                  <label>Pickup Point</label>
                  <Multiselect
                    isObject={true}
                    displayValue="name"
                    options={pickupPointsD}
                    showCheckbox
                    selectedValues={[]}
                    onRemove={(selectedCat) => {
                      const selectedIds = selectedCat.map((cat) => {
                        return cat._id
                      })
                      setFinalpickupPointsD(selectedIds)
                    }}
                    onSelect={(selectedCat) => {
                      const selectedIds = selectedCat.map((cat) => {
                        return cat._id
                      })
                      setFinalpickupPointsD(selectedIds)
                    }}
                  />
                </div>



                <div className="form-group col-md-3">
                  <label className="col-md-12 col-from-label">Search By Name</label>
                  <div>
                    <input type="text" className="form-control form-control-sm" id="search" name="search" placeholder="Type & Seach" onChange={onChangeHandler} />
                  </div>
                </div>

                <div className="col-lg-3 col-md-3 mt-3">
                  <button className='btn btn-primary mt-2' type='button' onClick={() => filterData(0)}>Search</button>
                </div>
              </div>


              <div className="card-body" style={{ overflowX: "auto" }}>
                <table className="table aiz-table mb-0 footable footable-1 breakpoint breakpoint-lg exppdf">
                  <thead>
                    <tr className="footable-header">
                      <th className="footable-first-visible" style={{ display: 'table-cell' }}># </th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Product</th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Variants</th>
                      {/* <th style={{ display: 'table-cell', textAlign: 'center' }}>Stock Qty</th> */}
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Category</th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Brand</th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Industry</th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Seller</th>
                      <th style={{ display: 'table-cell', textAlign: 'center' }}>Active</th>
                      <th data-breakpoints="lg" style={{ display: 'none' }}>Added By</th>
                      <th data-breakpoints="sm" style={{ display: 'table-cell', textAlign: 'center' }}>Info</th>
                      {/* <th data-breakpoints="md" style={{ display: 'none' }}>Total Stock</th> */}
                      <th data-breakpoints="lg" style={{ display: 'none' }}>Todays Deal</th>
                      <th data-breakpoints="lg" style={{ display: 'none' }}>Published</th>
                      <th data-breakpoints="lg" style={{ display: 'none' }}>Featured</th>
                      <th data-breakpoints="sm" className="text-right footable-last-visible" style={{ display: 'table-cell', textAlign: 'center' }}>Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bArr && bArr?.map((item, i) => {
                      return <tr key={i}>
                        <td className="footable-first-visible" style={{ display: 'table-cell' }}>
                          {(pageIndex * countToShowInTable) + i + 1}
                        </td>
                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          <div className="row gutters-5 w-200px w-md-300px mw-100">
                            {/* {item?.product?.variations?.length && <div className="col-auto w-50 ">
                              {item?.product?.variations[0]?.mainImage_url?.url ? <img src={item?.product?.variations[0]?.mainImage_url?.url} alt="Image" className="img-fluid" /> : <img src="https://reactfront.mmslfashions.in/uploads/products/main/images/chlor.jpg" alt="Image" className="img-fluid" />}
                            </div>} */}
                            <div className="col-auto w-50 ">
                              <img className="img-fluid" src={item?.isGlobalImage === true ? item?.mainImage_url : item?.variations[0]?.mainImage_url?.url} alt="Image" />
                            </div>
                            <div className="col">
                              <span className="text-muted text-truncate-2" style={{ fontSize: "18px", marginBottom: "10px" }}>{item?.name}</span>
                              <span className="text-muted text-truncate-2">Languages : {item?.languages}</span>
                              {/* {item?.product?.variations?.length && <div>
                                  <span>Mrp : Rs {item?.product?.variations[0]?.mrp}</span>,<br />
                                  <span>Sale : Rate Rs  {item?.product?.variations[0]?.sale_rate}</span>,<br />
                                  <span>Discount : Rs {item?.product?.variations[0]?.discount}</span>
                                </div>} */}
                            </div>
                          </div>
                        </td>

                        <td style={{ display: 'table-cell', textAlign: 'center', width: '400px', }}>
                          {item?.variations?.map((variation, index) => (
                            <div key={index}>
                              <b style={{fontSize:'18px'}}>Variant</b> : {variation?.weight}{" , "}
                              {variation?.prices?.map((price, i) => (
                                <div key={i}>
                                  <span key={i}><b>Price</b> : {price?.sale_rate}{" "}</span>{" , "}
                                  <span key={i}><b>Currency</b> : {price?.currency_id[0]?.name}{" "}</span>
                                </div>
                              ))}
                              {variation?.stock?.map((stockItem, i) => (
                                <div key={i}>
                                  <span key={i}><b>PickupPoints</b> : {stockItem?.pickupPoint[0]?.province}</span>{" , "}
                                  <span key={i}><b>Stock</b> : {stockItem?.qty}{" "}</span>{" , "}
                                  <span key={i}><b>Sku</b> : {stockItem?.sku}{" "}</span>{"  "}
                               
                                </div>
                              ))}
                              <hr></hr>
                            </div>
                               
                          ))}
                        </td>

                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          {item?.category_id && item?.category_id?.map((catItem, i) => {
                            return <span>{catItem?.name}</span>
                          })}
                        </td>

                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          {item?.brand_id && item?.brand_id}
                        </td>

                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          {item?.industry_id && item?.industry_id?.map((catItem, i) => {
                            return <span>{catItem?.name}</span>
                          })}
                        </td>

                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          {/* {item?.product?.seller_id && item?.product?.seller_id?.firstname + " " + item?.product?.seller_id && item?.product?.seller_id?.lastname} */}
                          {item?.seller_id}
                        </td>

                        <td style={{ display: "table-cell", textAlign: 'center' }}>
                          <label className="aiz-switch aiz-switch-success mb-0">
                            <input
                              onChange={() => { changeStatus(item) }}
                              type="checkbox"
                              checked={item?.approve}
                            />
                            <span className="slider round" />
                          </label>
                        </td>


                        <td style={{ display: 'table-cell', textAlign: 'center' }}>
                          <strong>Num of Sale:</strong> 0 Times <br />
                          <strong>Base Price:</strong>{item.unit_price}<br />
                          <strong>Rating:</strong> 0 <br />
                        </td>
                        {/* <td style={{ display: 'table-cell' }}>10</td> */}
                        <td style={{ display: 'none', textAlign: 'center' }}>
                          <label className="aiz-switch aiz-switch-success mb-0">
                            <input defaultValue={73} type="checkbox" />
                            <span className="slider round" />
                          </label>
                        </td>
                        <td style={{ display: 'none', textAlign: 'center' }}>
                          <label className="aiz-switch aiz-switch-success mb-0">
                            <input defaultValue={73} type="checkbox" defaultChecked />
                            <span className="slider round" />
                          </label>
                        </td>
                        <td style={{ display: 'none', textAlign: 'center' }}>
                          <label className="aiz-switch aiz-switch-success mb-0">
                            <input defaultValue={73} type="checkbox" />
                            <span className="slider round" />
                          </label>
                        </td>
                        <td className="text-right footable-last-visible" style={{ display: 'table-cell', textAlign: 'center', whiteSpace: 'nowrap' }}>
                          {/* <Link to="#" className="btn btn-soft-success btn-icon btn-circle btn-sm" title="View">
                              <i className="las la-eye" />
                            </Link> */}
                          <Link to={`edit/${item?.uid}`} className="btn btn-soft-primary btn-icon btn-circle btn-sm" title="Edit">
                            <i className="las la-edit" />
                          </Link>
                          {/* <a className="btn btn-soft-warning btn-icon btn-circle btn-sm" href="https://mmslfashions.in/admin/products/duplicate/73?type=All" title="Duplicate">
                              <i className="las la-copy" />
                            </a> */}

                          <button type="button" onClick={() => { deleteProductData(item?.uid) }} className="btn btn-soft-danger btn-icon btn-circle btn-sm">
                            <i className="las la-trash" />
                          </button>

                          <BsFillPrinterFill onClick={() => { changeRouting(item?.uid) }} className="btn btn-soft-primary btn-icon btn-circle btn-sm" />

                        </td>
                      </tr>
                    })}
                  </tbody>
                </table>

                <div className="aiz-pagination">
                  <nav>
                    {totalCount && <Pagination onChange={onChangeVal} total={totalCount} />}
                  </nav>
                </div>

              </div>
            </form>
          </div>

        </div >
        <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto"></div>

        <table className="table aiz-table mb-0 footable footable-1 breakpoint breakpoint-lg" id='table-to-xlsx' style={{ display: 'none' }}>
          <thead>
            <tr className="footable-header">
              <th className="footable-first-visible" style={{ display: 'table-cell' }}># </th>
              <th style={{ display: 'table-cell' }}>Product</th>
              <th style={{ display: 'table-cell' }}>Category</th>
              <th style={{ display: 'table-cell' }}>Brand</th>
              <th style={{ display: 'table-cell' }}>Seller</th>
              <th data-breakpoints="sm" style={{ display: 'table-cell' }}>Info</th>
            </tr>
          </thead>
          <tbody>

            {bArrr?.map((item, i) => {
              return <tr key={i}>
                <td className="footable-first-visible" style={{ display: 'table-cell' }}>
                  {/* {(pageIndex * countToShowInTable) + i + 1} */}
                  {i + 1}
                </td>
                <td style={{ display: 'table-cell' }}>
                  <div className="row gutters-5 w-200px w-md-300px mw-100">
                    <div className="col">
                      <span className="text-muted text-truncate-2" style={{ fontSize: "18px", marginBottom: "10px" }}>{item?.product?.name}</span>
                      <span className="text-muted text-truncate-2">Languages : {item?.languages}</span>
                    </div>
                  </div>
                </td>
                <td style={{ display: 'table-cell' }}>
                  {item?.categories && item?.categories?.map((catItem, i) => {
                    return <span>{catItem.name}</span>
                  })}
                </td>
                <td style={{ display: 'table-cell' }}>
                  {item?.product?.brand_id && item?.product?.brand_id.name}
                </td>
                <td style={{ display: 'table-cell' }}>
                  {item?.product?.seller_id && item?.product?.seller_id?.firstname + " " + item?.product?.seller_id && item?.product?.seller_id?.lastname}
                </td>
                <td style={{ display: 'table-cell' }}>
                  <strong>Num of Sale:</strong> 0 Times <br />
                  <strong>Base Price:</strong>{item.unit_price}<br />
                  <strong>Rating:</strong> 0 <br />
                </td>
              </tr>
            })}
          </tbody>
        </table>


      </div >
    </>
  )
}
export default AllProducts;