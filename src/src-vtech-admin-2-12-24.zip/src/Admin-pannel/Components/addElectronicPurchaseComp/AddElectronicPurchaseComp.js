import React from 'react'

function AddElectronicPurchaseComp() {

    const handelChange = (e) => {
        if (e.key === 'Enter') {
            const clone = e.target.value
            // setSearch(clone);
            // setShow(true)
        }
    }

    return (
        <>
            <div className="aiz-main-content">
                <div className="px-15px px-lg-25px">
                    <div className="card" style={{ padding: "10px" }}>

                        <div className="container">
                            <div className="row devTols" >
                                <div className="col-lg-3">
                                    <label>Order Entry No</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="reference_id" placeholder="Order Entry No" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3">
                                    <label>Entry Date</label>
                                    <div className="form-group mb-0">
                                        <input type="date" className="aiz-date-range form-control" name="start_date" placeholder="" data-format="DD-MM-Y" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>




                                <div className="col-lg-3 mt-2">
                                    <label>Supplier/Branch Name</label>
                                    <div className="form-group mb-0">
                                        <input type="text" className="aiz-date-range form-control" name="product_name" placeholder="Supplier/Branch Name" autoComplete="off" fdprocessedid="sq6vu7" />
                                    </div>
                                </div>

                                <div className="col-lg-3 mt-2">
                                    <label>Delivery From</label>
                                    <select class="form-select" aria-label="Default select example">
                                        <option selected>Open this select menu</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <div className="container">
                            <div className="row">
                                <div className="col">
                                    <div>
                                        <label>Products</label>
                                        <input className="form-control" onKeyDown={handelChange} placeholder="Please add products to order list" />
                                        {/* {show && searchPro?.getSearchedProduct?.length > 0 && <div className="showList">
                                            <div style={{ fontSize: "19px" }} onClick={() => { setShow(false) }}><RxCross1 /></div>
                                            {searchPro?.getSearchedProduct.map((item) => {
                                                return <h6 key={item._id} style={{ cursor: "pointer" }} onClick={() => setTableItem(item)}>{item.name}</h6>
                                            })}
                                        </div>} */}
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="container">
                            <div className="card mt-3 rest-part col-lg-12 mb-0">
                                {/* <div className="card-body"> */}
                                <div className="row p-0">
                                    <div className="col-12 sku_combination table-responsive form-group p-0 m-0" id="sku_combination">
                                        <table className="table table-bordered physical_product_show">
                                            <thead>
                                                <tr>
                                                    <td><label className="control-label">Sr.No.</label></td>
                                                    <td><label className="control-label">Product Name</label></td>
                                                    <td><label className="control-label">Stock</label></td>
                                                    <td><label className="control-label">Quantity</label></td>
                                                    <td><label className="control-label">Basic Rate</label></td>
                                                    <td><label className="control-label">Amount</label></td>
                                                    <td><label className="control-label"></label></td>
                                                </tr>

                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <label name="varient" className="control-label">1</label>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <input type="text" name="product_name" placeholder='' className="form-control" />
                                                    </td>
                                                    <td>
                                                        <button className='btn btn-primary' type='button'>
                                                            Add
                                                        </button>
                                                    </td>
                                                </tr>
                                                {/* 
                                                    {showData && showData.map((item, i) => {
                                                        return <GenerateTr changeSkuvalue={changeSkuvalue} showData={showData} setShowData={setShowData} DeleteRow={DeleteRow} key={i} item={item} index={i} pickUp={pickUp} />
                                                    })} */}
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                                {/* </div> */}
                            </div>
                        </div>


                        <div className="container">
                            <div className="row mt-3 mb-2">
                                <div className="col-4">
                                    <label>Comment</label>
                                    <input className="form-control" type="text" name="shipping" />
                                </div>
                            </div>
                            <div className="row mt-2 mb-3">
                                <div className="col-12">
                                    <label>Remark / Narration</label>
                                    <textarea className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <div style={{ marginLeft: "60px", display: "flex" }}>
                            <button type="button" style={{ display: "flex", alignContent: "center" }} className="btn btn-primary">Save </button>
                            <button type="button" className="btn btn-danger" style={{ marginLeft: "10px" }}>Reset</button>
                            <button type="button" className="btn btn-secondary" style={{ marginLeft: "10px" }}>Close</button>
                        </div>
                    </div>

                </div>
                <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto"></div>
            </div>
        </>
    )
}

export default AddElectronicPurchaseComp