import { Link } from "react-router-dom";
import {
    useDeleteBlogsMutation,
    useGetBlogsQuery,
} from "../all-products/allproductsApi/allProductsApi";
import { token } from "../../common/TokenArea";
import { useEffect, useState } from "react";
import axios from "axios";
import { Pagination } from "antd";

function AdvisoryListComp() {
    const [hitFilterApi, setHitFilterApi] = useState(false);
    const [searchByKeyAPi, setSearchByKeyAPi] = useState(false);
    const [inputVal, setInputVal] = useState({ search: '' });
    const [blankArr, setBlankArr] = useState([]);
    const [selectedVal, setSelectedVal] = useState();
    const [isLoadingg, setIsLoadingg] = useState();
    const [parentcategD, setParentcategD] = useState();

    const [totalCount, setTotalCount] = useState();
    const [pageIndex, setPageIndex] = useState(0)
    const [countToShowInTable, setCountToShowInTable] = useState(10);


    // const { isLoading, data } = useGetBlogsQuery(token);
    const [deleteBlogs, response] = useDeleteBlogsMutation();
    const deleteBlogsData = (id) => {
        // deleteBlogs(id);
    };
    if (response.isSuccess == true) {
        alert("Blog deleted Successfully");
    }



    const getAllProductsList = async (pageNo) => {
        if (hitFilterApi) {
            searchParentCategD(pageNo)
        } else if (searchByKeyAPi) {
            searchData(pageNo)
        } else {
            try {
                setIsLoadingg(true)
                const res = await axios.get(`https://onlineparttimejobs.in/api//page?page=${pageNo}&count=10&parent_id=&search=`, {
                    headers: {
                        'Content-type': 'application/json; charset=UTF-8',
                        'Authorization': 'Bearer ' + token
                    }
                });
                setIsLoadingg(false)
                console.log('AllBlogsData---', res?.data)
                setBlankArr(res?.data?.getallBlogs);
                setTotalCount(res?.data?.totalCount)
            } catch (error) {
                setIsLoadingg(false)
            }
        }
    };
    useEffect(() => {
        getAllProductsList(0);
    }, []);
    const onChangeVal = (e) => {
        getAllProductsList(e - 1)
        setPageIndex(e - 1)
    };


    const onChangeHandler = (e) => {
        const inpVal = e.target.value;
        setInputVal(inpVal);
    };
    const searchData = async (pageNo) => {
        try {
            setIsLoadingg(true)
            const res = await axios.get(`https://onlineparttimejobs.in/api//page?page=${pageNo}&count=10&parent_id=&search=${inputVal}`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            setIsLoadingg(false)
            setBlankArr(res?.data?.getallBlogs);
            setTotalCount(res?.data?.totalCount);
            setSearchByKeyAPi(true);
        } catch (error) {
            setIsLoadingg(false)
        }
    };

    const getParentCategoryData = async () => {
        try {
            const res = await axios.get(`https://onlineparttimejobs.in/api/`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            setParentcategD(res?.data)
            console.log('ParentBlog---', res?.data)
        } catch (error) {

        }
    };
    useEffect(() => {
        getParentCategoryData()
    }, []);

    const handleFilterParentCateg = (e) => {
        setSelectedVal(e.target.value)
    };
    const searchParentCategD = async (pageN) => {
        try {
            setIsLoadingg(true)
            const res = await axios.get(`https://onlineparttimejobs.in/api//page?page=${pageN}&count=10&parent_id=${selectedVal}&search=`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            setIsLoadingg(false)
            setBlankArr(res?.data?.getallBlogs);
            setTotalCount(res?.data?.totalCount);
            setHitFilterApi(true)
        } catch (error) {
            setIsLoadingg(false)
        }
    };


    return (
        <>
            <div
                className="aiz-main-content"
                style={{ backgroundColor: "#F2F3F8", marginTop: "0px" }}
            >
                {isLoadingg && <div className="preloaderCount">
                    <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                </div>}
                <div className="px-15px px-lg-25px">
                    <div className="aiz-titlebar text-left mt-2 mb-3">
                        <div className="row align-items-center">
                            <div className="col-auto">
                                <h1 className="h3">Advisory</h1>
                            </div>
                            <div className="col text-right">
                                <Link to="create" className="btn btn-circle btn-info">
                                    <span>Add New Advisory</span>
                                </Link>
                            </div>
                        </div>
                    </div>
                    <br />

                    <div className="card">

                        <div className="card-header d-block d-md-flex">
                            <h5 className="mb-0 h6">All Advisories</h5>
                            {/* <button className="btn btn-primary">Fetch AI Content</button> */}

                            <div style={{ display: 'flex' }}>
                                <select className="form-select me-2" aria-label="Default select example" name='parent_categ' onChange={(e) => handleFilterParentCateg(e, 0)} >
                                    <option selected>select Parent</option>
                                    {parentcategD && parentcategD?.map((item, i) => {
                                        return <option value={item?.uid} key={i}>{item?.name}</option>
                                    })}
                                </select>
                                <button
                                    type="button"
                                    onClick={() => searchParentCategD(0)}
                                    className="btn btn-primary"
                                    style={{ padding: "0 10px" }}
                                >
                                    Search
                                </button>
                            </div>
                            <form>
                                <div className="box-inline pad-rgt pull-left">
                                    <div style={{ minWidth: 200 }} className="d-flex">
                                        <input
                                            type="text"
                                            className="form-control me-2"
                                            id="search"
                                            name="search"
                                            placeholder="Type"
                                            fdprocessedid="rlhs3j"
                                            onChange={onChangeHandler}
                                        />
                                        <button

                                            type="button"
                                            onClick={() => searchData(0)}
                                            className="btn btn-primary"
                                            style={{ padding: "0 10px" }}
                                        >
                                            Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>



                        <div className="card-body">
                            <table
                                className="table aiz-table mb-0 footable footable-1 breakpoint breakpoint-lg"
                                style={{}}
                            >
                                <thead>
                                    <tr className="footable-header">
                                        <th
                                            className="footable-first-visible"
                                            style={{ display: "table-cell" }}
                                        >
                                            #{" "}
                                        </th>
                                        <th style={{ display: "table-cell", textAlign: 'left' }}>Title</th>
                                        <th style={{ display: "table-cell", textAlign: 'left' }}>Category</th>
                                        <th style={{ display: "table-cell", textAlign: 'left' }}>
                                            Short Description
                                        </th>
                                        <th style={{ display: "table-cell", textAlign: 'left' }}>Description</th>
                                        <th
                                            data-breakpoints="sm"
                                            className="text-right footable-last-visible"
                                            style={{ display: "table-cell" }}
                                        >
                                            Options
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {blankArr &&
                                        blankArr?.map((item, i) => {
                                            return (
                                                <tr key={item._id}>
                                                    <td
                                                        className="footable-first-visible"
                                                        style={{ display: "table-cell" }}
                                                        key={item._id}
                                                    >
                                                        {(pageIndex * countToShowInTable) + i + 1}
                                                    </td>

                                                    <td style={{ display: "table-cell" }}>
                                                        {item?.title}
                                                    </td>

                                                    <td style={{ display: "table-cell" }}>
                                                        {item?.category_id[0]?.name}
                                                    </td>
                                                    <td style={{ display: "table-cell" }}>
                                                        {item.short_description}
                                                    </td>
                                                    <td style={{ display: "table-cell" }}>
                                                        {item.description && item.description}
                                                    </td>

                                                    <td
                                                        className="text-right footable-last-visible"
                                                        style={{ display: "table-cell" }}
                                                    >
                                                        <Link
                                                            to="#"
                                                            className="btn btn-soft-success btn-icon btn-circle btn-sm"
                                                        >
                                                            <i className="las la-eye" />
                                                        </Link>
                                                        <Link
                                                            to={`edit/${item.uid}`}
                                                            className="btn btn-soft-primary btn-icon btn-circle btn-sm"
                                                        >
                                                            <i className="las la-edit" />
                                                        </Link>
                                                        <button
                                                            type="button"
                                                            onClick={() => deleteBlogsData(item.uid)}
                                                            className="btn btn-soft-danger btn-icon btn-circle btn-sm"
                                                        >
                                                            <i className="las la-trash" />
                                                        </button>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                </tbody>
                            </table>

                            <div className="aiz-pagination">
                                <nav>
                                    {totalCount && <Pagination onChange={onChangeVal} total={totalCount} />}
                                </nav>
                            </div>

                        </div>

                    </div>
                </div>
                <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto">
                    {/*p class="mb-0">&copy;  v6.3.3</p*/}
                </div>
            </div>
        </>
    );
}

export default AdvisoryListComp