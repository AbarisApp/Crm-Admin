import React from 'react'
import AddlabourChargeTypeComp from '../addLabourChargeTypeComp/AddlabourChargeTypeComp'

function EditLabourChargeTypeComp() {
    return (
        <>
            <AddlabourChargeTypeComp />
        </>
    )
}

export default EditLabourChargeTypeComp