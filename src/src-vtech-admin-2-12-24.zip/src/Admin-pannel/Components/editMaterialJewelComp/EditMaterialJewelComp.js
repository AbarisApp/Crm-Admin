import React from 'react'
import AddMaterialJewelPage from '../../Pages/addMeaterialJewelPage'

function EditMaterialJewelComp() {
    return (
        <>
            <AddMaterialJewelPage />
        </>
    )
}

export default EditMaterialJewelComp