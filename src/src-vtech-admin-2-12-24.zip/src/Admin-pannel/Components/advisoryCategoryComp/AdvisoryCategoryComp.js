import { Link } from "react-router-dom";
import { useDeleteBlogCategoryMutation, useGetBlogsCategoryQuery } from "../all-products/allproductsApi/allProductsApi";
import { Pagination } from "antd";
import axios from "axios";
import { useEffect, useState } from "react";


function AdvisoryCategoryComp() {
    const [hitFilterApi, setHitFilterApi] = useState(false);
    const [searchByKeyAPi, setSearchByKeyAPi] = useState(false);
    const [inputVal, setInputVal] = useState({ search: '' });
    const [blankArr, setBlankArr] = useState([]);
    const [selectedVal, setSelectedVal] = useState();
    const [isLoadingg, setIsLoadingg] = useState();
    const [parentcategD, setParentcategD] = useState();

    const [totalCount, setTotalCount] = useState();
    const [pageIndex, setPageIndex] = useState(0)
    const [countToShowInTable, setCountToShowInTable] = useState(10);

    const token = window.localStorage.getItem('token')

    // ----------------------------------------
    // const { isLoading, data } = useGetBlogsCategoryQuery();
    const [deleteBlogcat, response] = useDeleteBlogCategoryMutation();
    const deleteBlogCategoryData = (id) => {
        deleteBlogcat(id)
    };
    if (response.isSuccess === true) {
        alert('SellerBanner deleted Successfully')
    };
    // ----------------------------------------

    const getAllProductsList = async (pageNo) => {
        if (hitFilterApi) {
            searchParentCategD(pageNo)
        } else if (searchByKeyAPi) {
            searchData(pageNo)
        } else {
            try {
                setIsLoadingg(true)
                const res = await axios.get(`https://onlineparttimejobs.in/api/---/page?page=${pageNo}&count=10&parent_id=&search=`, {
                    headers: {
                        'Content-type': 'application/json; charset=UTF-8',
                        'Authorization': 'Bearer ' + token
                    }
                });
                setIsLoadingg(false)
                console.log('AllBlogsCateg---', res?.data)
                setBlankArr(res?.data?.category);
                setTotalCount(res?.data?.count)
            } catch (error) {
                setIsLoadingg(false)
            }
        }
    };
    useEffect(() => {
        getAllProductsList(0);
    }, []);
    const onChangeVal = (e) => {
        getAllProductsList(e - 1)
        setPageIndex(e - 1)
    };


    const onChangeHandler = (e) => {
        const inpVal = e.target.value;
        setInputVal(inpVal);
    };
    const searchData = async (pageNo) => {
        try {
            setIsLoadingg(true)
            const res = await axios.get(`https://onlineparttimejobs.in/api/----/page?page=${pageNo}&count=10&parent_id=&search=${inputVal}`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            setIsLoadingg(false)
            console.log('AllSellersREs---', res?.data)
            setBlankArr(res?.data?.category);
            setTotalCount(res?.data?.count);
            setSearchByKeyAPi(true);
        } catch (error) {
            setIsLoadingg(false)
        }
    };

    const getParentCategoryData = async () => {
        try {
            const res = await axios.get(`https://onlineparttimejobs.in/api/-----/parentadmin`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            console.log('parentBlog---', res?.data)
            setParentcategD(res?.data)
        } catch (error) {

        }
    };
    useEffect(() => {
        getParentCategoryData()
    }, []);

    const handleFilterParentCateg = (e) => {
        setSelectedVal(e.target.value)
    };
    const searchParentCategD = async (pageN) => {
        try {
            setIsLoadingg(true)
            const res = await axios.get(`https://onlineparttimejobs.in/api/----/page?page=${pageN}&count=10&parent_id=${selectedVal}&search=`, {
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer ' + token
                }
            });
            setIsLoadingg(false)
            console.log('AllSellersREs---', res?.data)
            setBlankArr(res?.data?.category);
            setTotalCount(res?.data?.count);
            setHitFilterApi(true)
        } catch (error) {
            setIsLoadingg(false)
        }
    };




    return (
        <>
            <div className="aiz-main-content">
                {isLoadingg && <div className="preloaderCount">
                    <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                </div>}
                <div className="px-15px px-lg-25px">
                    <div className="aiz-titlebar text-left mt-2 mb-3">
                        <div className="row align-items-center">
                            <div className="col-md-6">
                                <h1 className="h3 " id="bg_categories">All Advisory Category</h1>
                            </div>
                            <div className="col-md-6 text-md-right">
                                <Link to="create" className="btn btn-primary add_categories">
                                    <span className="text_categories">Add Advisory Category</span>
                                </Link>
                            </div>
                        </div>
                    </div>
                    <div className="card">

                        <div className="card-header d-block d-md-flex">
                            <h5 className="mb-0 h6">Advisory Category</h5>
                            <div style={{ display: 'flex' }}>
                                <select className="form-select me-2" aria-label="Default select example" name='parent_categ' onChange={(e) => handleFilterParentCateg(e, 0)} >
                                    <option selected>select Parent</option>
                                    {parentcategD && parentcategD?.map((item, i) => {
                                        return <option value={item?._id}>{item?.name}</option>
                                    })}
                                </select>
                                <button
                                    type="button"
                                    onClick={() => searchParentCategD(0)}
                                    className="btn btn-primary"
                                    style={{ padding: "0 10px" }}
                                >
                                    Search
                                </button>
                            </div>
                            <form>
                                <div className="box-inline pad-rgt pull-left">
                                    <div style={{ minWidth: 200 }} className="d-flex">
                                        <input
                                            type="text"
                                            className="form-control me-2"
                                            id="search"
                                            name="search"
                                            placeholder="Type"
                                            fdprocessedid="rlhs3j"
                                            onChange={onChangeHandler}
                                        />
                                        <button

                                            type="button"
                                            onClick={() => searchData(0)}
                                            className="btn btn-primary"
                                            style={{ padding: "0 10px" }}
                                        >
                                            Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div className="card-body">
                            <table className="table aiz-table mb-0 footable footable-1 breakpoint-xl" style={{}}>
                                <thead>
                                    <tr className="footable-header">
                                        <th className="footable-first-visible" style={{ display: 'table-cell', textAlign: 'center' }}>#</th>
                                        <th width="30%" style={{ display: 'table-cell', textAlign: 'center' }}>Name</th>
                                        {/* <th width="30%" style={{ display: 'table-cell' }}>Banner Name</th> */}
                                        {/* <th width="30%" style={{ display: 'table-cell' }}>Image</th> */}
                                        <th data-breakpoints="md" className="text-right footable-last-visible" style={{ display: 'table-cell', textAlign: 'center' }}>Options</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    {blankArr && blankArr?.map((item, i) => {
                                        return <tr key={item._id}>
                                            <td className="footable-first-visible" style={{ display: 'table-cell', textAlign: 'center' }}>
                                                {(pageIndex * countToShowInTable) + i + 1}
                                            </td>

                                            <td style={{ display: 'table-cell', textAlign: 'center' }}>
                                                {item?.name}
                                            </td>

                                            {/* <td style={{ display: 'table-cell' }}>
                          Banner 2
                        </td> */}

                                            {/* <td style={{ display: 'table-cell' }}>
                          Banner 2
                        </td> */}

                                            <td className="text-right footable-last-visible" style={{ display: 'table-cell', textAlign: 'center' }}>
                                                <Link to={`edit/${item.uid}`} className="btn btn-soft-info btn-icon btn-circle btn-sm" title="Approved">
                                                    <i className="las la-edit" />
                                                </Link>

                                                <button type="button" onClick={() => deleteBlogCategoryData(item.uid)} className="btn btn-soft-danger btn-icon btn-circle btn-sm">
                                                    <i className="las la-trash" />
                                                </button>
                                            </td>

                                        </tr>
                                    })}

                                </tbody>
                            </table>

                            <div className="aiz-pagination">
                                <nav>
                                    {totalCount && <Pagination onChange={onChangeVal} total={totalCount} />}
                                </nav>
                            </div>

                        </div>

                    </div>
                </div>
                <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto">

                </div>
            </div>

        </>
    )
}

export default AdvisoryCategoryComp