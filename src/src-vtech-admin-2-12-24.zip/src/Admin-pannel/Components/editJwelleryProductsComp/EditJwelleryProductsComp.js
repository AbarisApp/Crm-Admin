import React from 'react'
import AddJwelleryProductPage222 from '../../Pages/addJwelleryProduct222Page'

function EditJwelleryProductsComp() {
    return (
        <AddJwelleryProductPage222 />
    )
}

export default EditJwelleryProductsComp