import React from 'react'
import AddMetalPriceTypePage from '../../Pages/addMetalPriceTypePage'

function EditMetalPriceTypeComp() {
    return (
        <AddMetalPriceTypePage />
    )
}

export default EditMetalPriceTypeComp