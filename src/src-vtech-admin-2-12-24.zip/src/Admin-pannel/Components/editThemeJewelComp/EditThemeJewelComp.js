import React from 'react'
import AddThemeJewelPage from '../../Pages/addThemeJewelPage'

function EditThemeJewelComp() {
    return (
        <>
            <AddThemeJewelPage />
        </>
    )
}

export default EditThemeJewelComp