import React from 'react'
import CreateCostCentreCategoryCompo from '../createCostCentreCategoryCompo/CreateCostCentreCategoryCompo'

function EditCostCentreCategoryComp() {
    return (
        <>
            <CreateCostCentreCategoryCompo />
        </>
    )
}

export default EditCostCentreCategoryComp