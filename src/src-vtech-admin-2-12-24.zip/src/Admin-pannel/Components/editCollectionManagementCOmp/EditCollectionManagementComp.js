import React from 'react'
import AddCollectionManagementPage from '../../Pages/addCollectionManagmentPage'

function EditCollectionManagementComp() {
    return (
        <>
            <AddCollectionManagementPage />
        </>
    )
}

export default EditCollectionManagementComp