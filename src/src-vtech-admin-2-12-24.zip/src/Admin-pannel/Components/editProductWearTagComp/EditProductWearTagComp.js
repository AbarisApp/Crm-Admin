import React from 'react'
import AddProductWearTagComp from '../addProductWearTagComp/AddProductWearTagComp'

function EditProductWearTagComp() {
    return (
        <>
            <AddProductWearTagComp />
        </>
    )
}

export default EditProductWearTagComp