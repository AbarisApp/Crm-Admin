import React from 'react'
import CreateVoucherTypeComp from '../createVoucherTypeComp/CreateVoucherTypeComp'

function EditVoucherTypeComp() {
    return (
        <>
            <CreateVoucherTypeComp />
        </>
    )
}

export default EditVoucherTypeComp